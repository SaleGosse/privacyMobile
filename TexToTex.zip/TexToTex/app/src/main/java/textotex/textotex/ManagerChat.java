package textotex.textotex;

public class ManagerChat {
        public boolean left;
        public String message;
        public String date;
        public String name;

        public ManagerChat(boolean left, String message, String date, String name)
        {
            super();
            this.left = left;
            //this.left = false;
            this.message = message;
            this.date = date;
            this.name = name;
        }

}
